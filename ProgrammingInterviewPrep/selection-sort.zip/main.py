# Selection sort
# everytime I need to find the minimum element from 
# the remaining arrya and then swap it with the assumed minimum element

def selectionSort(arr):
    for i in range(len(arr)):
        min_ele_index_assumed=i
        for j in range(i+1,len(arr)):
            if arr[min_ele_index_assumed]>arr[j]:
                min_ele_index_assumed=j
        arr[i],arr[min_ele_index_assumed]=arr[min_ele_index_assumed],arr[i]


arr=[4,3,5,6,2,90,8,7,9]
selectionSort(arr)
print(arr)

# Quick Sort:

# [2,3,4,5,1,9,0,6777,7]

def partition(arr,start,end):
    pivot=arr[start]
    i=start
    for j in range(start+1, len(arr)):
        if arr[j]<pivot:
            i+=1
            arr[i],arr[j]=arr[j],arr[i]
    arr[i],arr[start]=arr[start],arr[i]
    return i
    
    

def quickSort(arr, start, end):
    if start<end:
        mid=partition(arr,start,end)
        quickSort(arr,start,mid-1)
        quickSort(arr,mid+1,end)
        
arr1=[2,3,4,5,1,9,0,6777,7]
quickSort(arr1,0,len(arr1)-1)
print(arr1)
        
    
    