# Quick Sort Algorithm
# randomized quick sort
# [3,4,5,6,1,2]

def partition(arr, p, r):
    # value to swap for randomization
    valueToSwap=len(arr)//2
    arr[p],arr[valueToSwap]=arr[valueToSwap],arr[p]
    pivot=arr[p]
    i=p
    for j in range(p+1,r+1):
        if pivot>arr[j]:
            i+=1
            arr[i],arr[j]=arr[j],arr[i]
    arr[p], arr[i]=arr[i],arr[p]
    return i
    
def quickSort(arr, p , r):
    if p<r:
        q = partition(arr,p,r)
        quickSort(arr,p, q-1)
        quickSort(arr,q+1, r)
        
        
arr=[9,8,7,6,5,4,3,2,1,0]




quickSort(arr,0,len(arr)-1)
print(arr)

        
