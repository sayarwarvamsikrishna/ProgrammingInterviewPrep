# Square Pattern

def squarePattern(length):
    for i in range(length):
        for j in range(length):
            print("* ", end='')
        print()
        
squarePattern(10)


# Triangular Pattern:
    
def triangularPattern(maxlength):
    i=1
    for i in range(maxlength+1):
        for j in range(i):
            print("* ", end='')
        print()
        
triangularPattern(10)




# Triangular Pattern:
    
def triangularPattern(maxlength):
    # i=1
    for i in range(maxlength):
        for j in range(maxlength-i):
            print("* ", end='')
        print()
        
triangularPattern(10)



# Upper half od the square
def upperSquarePattern(length):
    for i in range(length):
        for j in range(length):
            if j<i:
                print("  ", end='')
            else:
                print("* ", end='')
        print()
        
upperSquarePattern(10)

# Pyramid
def pattern4(size):
    i=1
    for i in range(size+1):
        for j in range(size+1-i):
            print(" ", end="")
        # value=size+1-i
        for j in range(i):
            # value,size+1):
            print("* ", end="")
        print()
pattern4(10)
            
# pyramid to print numbers

def pattern5(base):
    i=1
    cnt=1
    for i in range(base+1):
        for j in range(base+1-i):
            print(' ', end="")
            
        for j in range(i):
            print('{} '.format(cnt) , end="")
            cnt+=1
        print()
        
pattern5(10)
        
            
import math           
def pattern6(base):
    n=math.ceil((base+1)/2)
    for i in range(base):
        if i<=n:
            for j in range(i):
                print("* ", end="")
            # print()
        else:
            for j in range(base+1-i):
                    print("* ", end="")
        print()
    print("* ")
    
pattern6(11)

print("==="*100)
def pattern7(base):
    base+=1
    for i in range(base):
        if i<1:
            for j in range(i):
                print("* ")
        elif i==base-1:
            for j in range(i):
                print("* ", end="")
            print()
        else:
            for j in range(i):
                if j<1 or j==i-1:
                    print("* ", end="")
                else:
                    print("  ",end="")
            print()
pattern7(1)
                
                
    
    
    
                
                
                
                
    
    
    
        