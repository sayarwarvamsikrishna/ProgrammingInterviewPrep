# Counting sorted
# [4,2,2,5,3,3,1]

def countingSort(arr, lowerlimit, upperlimit):
    auxilaryArr=[0]*(upperlimit+1)
    result=[0]*len(arr)
    # Store count of each element in auxilary bytearray
    
    for i in range(len(arr)):
        auxilaryArr[arr[i]]+=1
        
    # Store cumulative sum
    
    for i in range(1,len(auxilaryArr)):
        auxilaryArr[i]+=auxilaryArr[i-1]
    #find the index of each elememnt of original array in 
    # count array and place the elements in resultant array
    
    i = len(arr)-1
    while i >= 0:
        result[auxilaryArr[arr[i]]-1]=arr[i]
        auxilaryArr[arr[i]]-=1
        i-=1
    return result     

arr=[4,2,2,5,3,3,1]
lowerlimit=min([4,2,2,5,3,3,1])
upperlimit=max([4,2,2,5,3,3,1])
result = countingSort(arr,lowerlimit,upperlimit)
print(result)


