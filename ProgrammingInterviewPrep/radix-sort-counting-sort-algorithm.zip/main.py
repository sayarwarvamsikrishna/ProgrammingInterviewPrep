# radix sort

# [121,432,564,23,1,45,788]

def countingSort(arr,place):
    l=len(arr)
    auxilaryArr=[0]*10
    resultArr=[0]*l
    
    # COunting the number of occurances
    for i in range(l):
        index=arr[i]//place
        auxilaryArr[index%10]+=1
        
        
    #count the cumulative sum
    for i in range(len(auxilaryArr)):
        auxilaryArr[i]+=auxilaryArr[i-1]
        
    i = l-1
    while i>=0:
        index = arr[i] // place
        
        resultArr[auxilaryArr[index%10]-1]=arr[i]
        auxilaryArr[index%10]-=1
        i-=1
        
    for i in range(l):
        arr[i]=resultArr[i]
    
    
def radixSort(arr):
    maxElement=max(arr)
    place=1
    while maxElement//place >0:
        countingSort(arr,place)
        place*=10
        
arr=[121,432,564,23,1,45,788,1000]
radixSort(arr)
print(arr)

